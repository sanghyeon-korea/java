package com.example.fitnessapp;

import android.content.Context;
import android.content.Intent;
import android.os.Bundle;
import android.view.*;
import android.widget.*;
import androidx.appcompat.app.AlertDialog;
import androidx.appcompat.app.AppCompatActivity;

import java.io.FileOutputStream;
import java.text.SimpleDateFormat;
import java.util.Date;
import java.util.Locale;

public class WorkoutActivity extends AppCompatActivity {

    EditText editExerciseName, editSets, editReps;
    Button btnAddWorkout, btnShowRecords;

    String username;
    final String FILE_NAME = "workout.txt";

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_workout);

        editExerciseName = findViewById(R.id.editExerciseName);
        editSets = findViewById(R.id.editSets);
        editReps = findViewById(R.id.editReps);
        btnAddWorkout = findViewById(R.id.btnAddWorkout);
        btnShowRecords = findViewById(R.id.btnShowRecords);

        // 로그인한 사용자 이름 전달 받기
        username = getIntent().getStringExtra("username");

        btnAddWorkout.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                String exercise = editExerciseName.getText().toString().trim();
                String sets = editSets.getText().toString().trim();
                String reps = editReps.getText().toString().trim();

                if (exercise.isEmpty() || sets.isEmpty() || reps.isEmpty()) {
                    Toast.makeText(WorkoutActivity.this, "모든 항목을 입력하세요", Toast.LENGTH_SHORT).show();
                    return;
                }

                String date = new SimpleDateFormat("yyyy-MM-dd", Locale.getDefault()).format(new Date());
                String record = username + "," + exercise + "," + sets + "," + reps + "," + date + "\n";

                try {
                    FileOutputStream fos = openFileOutput(FILE_NAME, Context.MODE_APPEND);
                    fos.write(record.getBytes());
                    fos.close();

                    Toast.makeText(WorkoutActivity.this, "운동 기록이 저장되었습니다", Toast.LENGTH_SHORT).show();

                    editExerciseName.setText("");
                    editSets.setText("");
                    editReps.setText("");

                } catch (Exception e) {
                    e.printStackTrace();
                    Toast.makeText(WorkoutActivity.this, "저장 중 오류 발생", Toast.LENGTH_SHORT).show();
                }
            }
        });

        btnShowRecords.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Intent intent = new Intent(WorkoutActivity.this, RecordActivity.class);
                intent.putExtra("username", username);
                startActivity(intent);
            }
        });
    }

    // 메뉴 생성
    @Override
    public boolean onCreateOptionsMenu(Menu menu) {
        getMenuInflater().inflate(R.menu.stretch_menu, menu);
        return true;
    }

    // 메뉴 클릭 이벤트
    @Override
    public boolean onOptionsItemSelected(MenuItem item) {
        switch (item.getItemId()) {
            case R.id.menu_arm:
                showStretchDialog("팔");
                return true;
            case R.id.menu_leg:
                showStretchDialog("다리");
                return true;
            case R.id.menu_chest:
                showStretchDialog("가슴");
                return true;
            case R.id.menu_shoulder:
                showStretchDialog("어깨");
                return true;
            case R.id.menu_back:
                showStretchDialog("등");
                return true;
            default:
                return super.onOptionsItemSelected(item);
        }
    }

    // 스트레칭 설명 팝업
    private void showStretchDialog(String part) {
        String message = "";

        switch (part) {
            case "팔":
                message = "팔을 몸 앞으로 교차하고 반대 손으로 팔꿈치를 당겨주세요.\n각 팔을 15~30초씩 유지하세요.";
                break;
            case "다리":
                message = "한쪽 다리를 앞으로 뻗고 반대쪽 다리를 접은 뒤\n발끝을 손으로 잡으려 하며 15~30초 유지하세요.";
                break;
            case "가슴":
                message = "두 팔을 뒤로 뻗어 손을 깍지 끼고 가슴을 천천히 들어 올립니다.\n자세를 15~30초 유지하세요.";
                break;
            case "어깨":
                message = "오른쪽 어깨를 앞으로 돌리고 왼손으로 오른팔을 가볍게 당겨줍니다.\n각 어깨를 15~30초씩 유지하세요.";
                break;
            case "등":
                message = "손바닥을 벽에 대고 몸과 팔을 90도 각도로 만든 후\n머리를 겨드랑이 아래로 밀며 15~30초 유지하세요.";
                break;
        }

        new AlertDialog.Builder(this)
                .setTitle(part + " 스트레칭 방법")
                .setMessage(message)
                .setPositiveButton("확인", null)
                .show();
    }
}
