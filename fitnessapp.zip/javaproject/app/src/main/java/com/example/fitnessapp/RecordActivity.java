package com.example.fitnessapp;

import android.content.Context;
import android.os.Bundle;
import android.widget.TextView;
import android.widget.Toast;
import androidx.appcompat.app.AppCompatActivity;

import java.io.*;

public class RecordActivity extends AppCompatActivity {

    TextView textRecords;
    final String FILE_NAME = "workout.txt";

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_record);

        textRecords = findViewById(R.id.textRecords);

        String username = getIntent().getStringExtra("username");
        if (username == null) {
            Toast.makeText(this, "사용자 정보가 없습니다", Toast.LENGTH_SHORT).show();
            return;
        }

        StringBuilder builder = new StringBuilder();
        builder.append("▶ ").append(username).append("님의 운동 기록\n\n");
        builder.append(String.format("%-10s %-8s %-6s %-6s\n", "날짜", "운동", "세트", "반복"));
        builder.append("--------------------------------\n");

        try {
            FileInputStream fis = openFileInput(FILE_NAME);
            BufferedReader reader = new BufferedReader(new InputStreamReader(fis));
            String line;
            boolean found = false;

            while ((line = reader.readLine()) != null) {
                String[] parts = line.split(",");
                if (parts.length == 5 && parts[0].equals(username)) {
                    String exercise = parts[1];
                    String sets = parts[2];
                    String reps = parts[3];
                    String date = parts[4];

                    builder.append(String.format("%-10s %-8s %-6s %-6s\n", date, exercise, sets, reps));
                    found = true;
                }
            }
            reader.close();

            if (!found) {
                builder.append("\n기록이 없습니다.");
            }

        } catch (IOException e) {
            builder.append("파일을 읽을 수 없습니다.");
            e.printStackTrace();
        }

        textRecords.setText(builder.toString());
    }
}
